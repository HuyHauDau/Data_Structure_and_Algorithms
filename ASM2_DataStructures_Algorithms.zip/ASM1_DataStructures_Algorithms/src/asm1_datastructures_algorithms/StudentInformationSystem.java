package asm1_datastructures_algorithms;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.HashSet;
import java.util.Set;

//public class StudentInformationSystem{
//    private final List<Student> students;
//    private final Scanner scanner;
//    public StudentInformationSystem(){
//        students = new ArrayList<>();
//        scanner = new Scanner(System.in);
//    }
//    public void addStudent(){
//        System.out.println("Enter student ID: ");
//        String id = scanner.nextLine();
//        System.out.println("Enter student Name: ");
//        String name = scanner.nextLine();
//        System.out.println("Enter student Marks: ");
//        float mark = scanner.nextFloat();
//        scanner.nextLine();
//        
//        students.add(new Student(id, name, mark));
//        System.out.println("Student added successfully.");   
//    }

public class StudentInformationSystem {
    private final Set<String> studentIds;
    private final List<Student> students;
    private final Scanner scanner;

    public StudentInformationSystem() {
        students = new ArrayList<>();
        studentIds = new HashSet<>();
        scanner = new Scanner(System.in);
    }

    public void addStudent() {
        String id;
        String name;
        float mark = 0;
        boolean validInput = false;
        while (true) {
            System.out.println("Enter student ID: ");
            id = scanner.nextLine().trim();
            if (id.isEmpty()) {
                System.out.println("ID cannot be empty. Please enter a valid ID.");
            } else if (studentIds.contains(id)) {
                System.out.println("A student with this ID already exists. Please enter a unique ID.");
            } else {
                break;
            }
        }
        while (true) {
            System.out.println("Enter student Name: ");
            name = scanner.nextLine().trim();
            if (name.isEmpty()) {
                System.out.println("Name cannot be empty. Please enter a valid name.");
            }else if (!name.matches("[a-zA-Z\\s]+")) {
                System.out.println("Name can only contain alphabetic characters and spaces. Please enter a valid name.");
            }else {
                break;
            }
        }
        while (!validInput) {
            System.out.println("Enter student Marks (0-10): ");
            String marksInput = scanner.nextLine().trim();
            try {
                mark = Float.parseFloat(marksInput);
                if (mark < 0 || mark > 10) {
                    System.out.println("Marks should be within the 0-10 range. Please enter valid marks.");
                } else {
                    validInput = true;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numeric marks.");
            }
        }
        students.add(new Student(id, name, mark));
        studentIds.add(id);
        System.out.println("Student added successfully.");
    }
//    public void editStudent(){
//        System.out.println("Enter student ID to edit: ");
//        String id = scanner.nextLine();
//        for (Student student : students){
//            if (student.getID().equals(id)){
//                System.out.println("Enter new name: ");
//                String name = scanner.nextLine();
//                System.out.println("Enter new marks: ");
//                float mark = scanner.nextFloat();
//                scanner.nextLine();                
//                student.setName(name);
//                student.setMark(mark);
//                System.out.println("Student updated successfully");
//                return;
//            }
//        }
//    }
    public void editStudent() {
        System.out.println("Enter student ID to edit: ");
        String id = scanner.nextLine().trim();
        Student studentToEdit = null;
        for (Student student : students) {
            if (student.getID().equals(id)) {
                studentToEdit = student;
                break;
            }
        }
        if (studentToEdit == null) {
            System.out.println("Student ID not found. Please enter a valid ID.");
            return;
        }
        while (true) {
            System.out.println("Enter new name: ");
            String name = scanner.nextLine().trim();
            if (name.isEmpty()) {
                System.out.println("Name cannot be empty. Please enter a valid name.");
            } else if (!name.matches("[a-zA-Z\\s]+")) {
                System.out.println("Name can only contain alphabetic characters and spaces. Please enter a valid name.");
            } else {
                studentToEdit.setName(name);
                break;
            }
        }
        while (true) {
            System.out.println("Enter new marks (0-10): ");
            String marksInput = scanner.nextLine().trim();
            try {
                float mark = Float.parseFloat(marksInput);
                if (mark < 0 || mark > 10) {
                    System.out.println("Marks should be within the 0-10 range. Please enter valid marks.");
                } else {
                    studentToEdit.setMark(mark);
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter numeric marks.");
            }
        }

        System.out.println("Student updated successfully.");
    }

//    public void sortStudent(){
//        int n = students.size();
//        boolean swapped;
//        for (int i = 0; i < n - 1; i++) {
//            swapped = false;
//            for (int j = 0; j < n - 1 - i; j++) {
//                if (students.get(j).getMark() < students.get(j + 1).getMark()) {
//                    Student temp = students.get(j);
//                    students.set(j, students.get(j + 1));
//                    students.set(j + 1, temp);
//                    swapped = true;
//                }
//            }
//            if (!swapped) break;
//        } 
//        System.out.println("Student sorted successfully");
//    }
        public void sortStudent() {
        mergeSort(students, 0, students.size() - 1);
        System.out.println("Students sorted successfully.");
    }

    private void mergeSort(List<Student> list, int left, int right) {
        if (left < right) {
            int mid = (left + right) / 2;
            mergeSort(list, left, mid);
            mergeSort(list, mid + 1, right);
            merge(list, left, mid, right);
        }
    }

    private void merge(List<Student> list, int left, int mid, int right) {
        List<Student> leftList = new ArrayList<>(list.subList(left, mid + 1));
        List<Student> rightList = new ArrayList<>(list.subList(mid + 1, right + 1));

        int i = 0, j = 0, k = left;
        while (i < leftList.size() && j < rightList.size()) {
            if (leftList.get(i).getMark() >= rightList.get(j).getMark()) {
                list.set(k++, leftList.get(i++));
            } else {
                list.set(k++, rightList.get(j++));
            }
        }
        while (i < leftList.size()) {
            list.set(k++, leftList.get(i++));
        }
        while (j < rightList.size()) {
            list.set(k++, rightList.get(j++));
        }
    }
//    public void delStudent(){
//        System.out.println("Enter Student ID to delete: ");
//        String id = scanner.nextLine();
//        students.removeIf(student -> student.getID().equals(id));
//        System.out.println("Student deleted successfully");
//    }
    public void delStudent() {
    System.out.println("Enter Student ID to delete: ");
    String id = scanner.nextLine().trim();
    if (id.isEmpty()) {
        System.out.println("ID cannot be empty. Please enter a valid ID.");
        return;
    }
    boolean removed = students.removeIf(student -> student.getID().equals(id));
    if (removed) {
        System.out.println("Student deleted successfully.");
    } else {
        System.out.println("Student ID not found. No student was deleted.");
    }
    }
//    public void searchStudentByID(){
//        System.out.println("Enter Student ID to search: ");
//        String id = scanner.nextLine();
//        for (Student student : students){
//            if (student.getID().equals(id)){
//                System.out.println(student);
//                return;
//            }
//        }
//        System.out.println("Student not found");
//    }
    public void searchStudentByID() {
    System.out.println("Enter Student ID to search: ");
    String id = scanner.nextLine().trim();
    if (id.isEmpty()) {
        System.out.println("ID cannot be empty. Please enter a valid ID.");
        return;
    }
    boolean found = false;
    for (Student student : students) {
        if (student.getID().equals(id)) {
            System.out.println(student);
            found = true;
            break;
        }
    }
    if (!found) {
        System.out.println("Student not found.");
    }
    }
    
//    public void displayAllStudents(){
//    if (students.isEmpty()){
//        System.out.println("No Students to display");
//    } else{
//        for (Student student : students){
//            System.out.println(student);
//        }
//    }
//    }
    public void displayAllStudents() {
    if (students == null) {
        System.out.println("Error: Student list is not initialized.");
        return;
    }

    if (students.isEmpty()) {
        System.out.println("No students to display.");
    } else {
        System.out.println("List of Students:");
        for (Student student : students) {
            System.out.println(student);
        }
    }
    }
}

