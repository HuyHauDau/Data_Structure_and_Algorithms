
package asm1_datastructures_algorithms;

public class Student {
    private String name;
    private String id;
    private float mark;
    
    public Student(String id, String name, float mark) {
        this.id = id;
        this.name = name;
        this.mark = mark;
    }
    public void setID(String id){
        this.id = id;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setMark(float mark) {
        this.mark = mark;
    }

    public float getMark() {
        return mark;
    }
    public String getName(){
        return name;
    }
    public String getID() {
        return id;
    }
    public String getRanking(){
        if(mark < 5.0) return "Fail";
        else if(mark < 6.5) return "Medium";
        else if(mark <7.5) return "Good";
        else if(mark < 9.0) return "Very Good";
        else return "Excellent";
    }
    @Override
    public String toString(){
        return "Student ID: " + id + ", Student Name: " + name + ", Student Mark: " + mark + ", Student Rank: " + getRanking();
    }
}
