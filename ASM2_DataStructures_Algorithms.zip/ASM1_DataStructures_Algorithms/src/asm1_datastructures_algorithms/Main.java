
package asm1_datastructures_algorithms;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        StudentInformationSystem system = new StudentInformationSystem();
        Scanner scanner = new Scanner(System.in);

    Map<Integer, Runnable> options = new HashMap<>();
        options.put(1, system::addStudent);
        options.put(2, system::editStudent);
        options.put(3, system::delStudent);
        options.put(4, system::sortStudent);
        options.put(5, system::searchStudentByID);
        options.put(6, system::displayAllStudents);

    while(true){
            System.out.println("1. Add Student");
            System.out.println("2. Edit Student");
            System.out.println("3. Delete Student");
            System.out.println("4. Sort Student");
            System.out.println("5. Search Student by ID");
            System.out.println("6. Display All Students");
            int option = scanner.nextInt();
            Runnable action = options.get(option);
            if (action != null) {
                action.run();
            } else {
                System.out.println("Invalid option. Please try again");
            }
        }

    }
}


